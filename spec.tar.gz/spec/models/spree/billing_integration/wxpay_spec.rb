require 'spec_helper'

describe Spree::Gateway::AlipayDualfun do
 
  it "should be valid" do
    
  end
 
end
